function [draw_Xr, draw_Yr] = interpolation(T, w_c, X_o)
    draw_Xr = X_o;
    draw_Yr = zeros(1, length(draw_Xr));
    for k = 1 : length(draw_Xr)
        s = 0;
        for v = -100 : 100
            s = s + signal(v * T) * h(draw_Xr(k) - v * T, w_c, T);
        end
        draw_Yr(k) = s;
    end
end

function ht = h(t, w_c, T)
    ht = w_c * T * sinc(w_c * t / pi) / pi;
end


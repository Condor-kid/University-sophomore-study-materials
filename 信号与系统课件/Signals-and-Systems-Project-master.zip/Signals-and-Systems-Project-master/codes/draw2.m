% draw figure 2 in this paper
clear all
T = 1;
[X_s1, Y_s1] = sampling(T, -2 * pi, 2 * pi);
subplot(2, 1, 1)
stem(X_s1, Y_s1)
title("采样信号 (T = 1)")
xlabel("$t$", "Interpreter", "Latex")
ylabel("$f_p(t)$", "Interpreter", "Latex")
hold on
grid on
draw_X = -2 * pi : 0.00001 * pi : 2 * pi;
draw_Y = signal(draw_X);
plot(draw_X, draw_Y)

xlim([-2 * pi, 2 * pi])
ylim([-0.5 1.5])
xticks(-2 * pi : 0.5 * pi : 2 * pi)
xticklabels({"-2\pi", "-3\pi/2", "-\pi", "-\pi/2", "0", "\pi/2", "\pi", "3\pi/2", "2\pi"})

[X_r, FT_r] = FT_s(T, -10, 10);
subplot(2, 1, 2);
plot(X_r, FT_r);
title("采样频谱 (T = 1)")
xlabel("$\omega$", "Interpreter", "Latex")
ylabel("$F_p(\mathrm{j}\omega)$", "Interpreter", "Latex")
grid on
xlim([-10, 10])
ylim([-1, 4])
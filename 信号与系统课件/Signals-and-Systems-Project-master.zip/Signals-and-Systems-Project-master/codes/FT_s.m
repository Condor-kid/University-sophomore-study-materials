% implement Fourier Transformation on sampled f(t)
function [X_r, FT_r] = FT_s(T, a, b)
    w_s = 2 * pi / T; % sample \omega threshold
    X_r = a : 0.01 : b; % interval of X_r to be drawn
    FT_r = zeros(1, length(X_r));
    % calculate FT_r by equation 13 in the report
    for w = 1 : length(X_r)
        s = 0;
        for k = -100: 100
            s = s + FT(X_r(w) - k * w_s);
        end
        FT_r(w) = 1 / T * s;
    end
end

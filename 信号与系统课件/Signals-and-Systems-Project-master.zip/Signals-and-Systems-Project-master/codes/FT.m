% implement Fourier Transformation on f(t)
function X = FT(w)
    % X = (sin(pi * w) / w) + 0.5 * ((sin(pi * (w - 1)) / (w - 1)) + (sin(pi * (w + 1)) / (w + 1)));
    % use sinc here to avoid divide-0 exception
    X = pi .* (sinc(w) + 0.5 .* (sinc(w - 1) + sinc(w + 1)));
end
% implement low-pass-filter whose cut-off frequency is w_c
function [X_c, FT_c, F_c] = low_pass_filter(T, w_c, X_r, FT_r)
    % w_c = 2.4;
    % X_c = X_r;
    logic_index = abs(X_r) <= w_c; % select frequenct field within w_c
    X_c = X_r(logic_index);
    FT_c = FT_r(logic_index);
    FT_c = FT_c .* T;

    F_c = zeros(1, length(X_r)); 
    F_c(logic_index) = T .* ones(1, length(X_c));
end
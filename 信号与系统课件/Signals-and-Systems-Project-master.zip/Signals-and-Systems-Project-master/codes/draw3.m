% draw figure 3 in this paper
clear all
T = pi / 2;
w_c = 2.4;
[X_r, FT_r] = FT_s(T, -10, 10);
[X_c, FT_c, F_c] = low_pass_filter(T, w_c, X_r, FT_r);

subplot(2, 1, 1);
plot(X_r, T * FT_r);
title("重建信号频谱 (T = \pi/2)")
xlabel("$\omega$", "Interpreter", "Latex")
ylabel("$F_p(\mathrm{j}\omega)$", "Interpreter", "Latex")
grid on
line([-w_c, -w_c], [-10, 10], "Color", "r")
line([w_c, w_c], [-10, 10], "Color", "r")
xlim([-10, 10])
ylim([-1, 4])

subplot(2, 1, 2);
plot(X_r, F_c);
title("理想低通滤波器 (\omega_c = 2.4)")
xlabel("$\omega$", "Interpreter", "Latex")
ylabel("$H(\mathrm{j}\omega)$", "Interpreter", "Latex")
grid on
xlim([-10, 10])
ylim([-1, 4])

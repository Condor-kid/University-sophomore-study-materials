% return a vector as output f(t) of input vector t
function y = signal(t)
    y = (abs(t) <= pi) .* 0.5 .* (1 + cos(t));
end
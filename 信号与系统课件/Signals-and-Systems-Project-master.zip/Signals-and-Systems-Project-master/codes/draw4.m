% draw figure 4 in this paper
clear all
T = 1; 
w_c = 2.4;
n = -6 : 6;
dt = pi / 256;
t = -2 * pi : dt : 2 * pi;
t_nT = ones(length(n), 1) * t - n' * T * ones(1, length(t));
fp = signal(n * T);
fr = fp * T * (sin(w_c*t_nT)./(pi*t_nT));
fo = signal(t);

subplot(2, 1, 1);
plot(t, fr)
hold on
plot(t, fo)
grid on
xlim([-2 * pi, 2 * pi])
ylim([-.2, 2])
xlabel("$t$", "Interpreter", "Latex")
ylabel("$f(t) \& f_r(t)$", "Interpreter", "Latex")
title("重建信号 (T = 1)")
legend("$f_r(t)$", "$f(t)$", "Interpreter", "Latex")

subplot(2, 1, 2);
plot(t, abs(fr - fo));
grid on
xlim([-2 * pi, 2 * pi])
title("重建信号与原信号的绝对误差 (T = 1)")
xlabel("$t$", "Interpreter", "Latex")
ylabel("$|f(t) - f_r(t)|$", "Interpreter", "Latex")
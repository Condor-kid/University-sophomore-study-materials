function [X_s, Y_s] = sampling(T, a, b)
    f = 1 / T;
    % X_s = a : T : b;
    X_s = generate_X(T, a, b);
    Y_s = signal(X_s);
end

function X = generate_X(T, a, b)
    one_side_size = fix((b - a) / T);
    X = zeros(1, 1 + 2 * one_side_size);
    X(1 + one_side_size) = 0;
    for k = 1 : one_side_size
        X(k) = -(one_side_size - k + 1) * T;
        X(k + one_side_size + 1) = k * T;
    end
end
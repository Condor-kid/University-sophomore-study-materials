% draw figure 1 in this paper
draw_X = -2 * pi : 0.00001 * pi : 2 * pi;
draw_Y = signal(draw_X);
subplot(2, 1, 1);
plot(draw_X, draw_Y)
title("信号波形")
xlabel("$t$", "Interpreter", "Latex")
ylabel("$f(t)$", "Interpreter", "Latex")
grid on
xlim([-2 * pi, 2 * pi])
ylim([-0.5 1.5])
xticks(-2 * pi : 0.5 * pi : 2 * pi)
xticklabels({"-2\pi", "-3\pi/2", "-\pi", "-\pi/2", "0", "\pi/2", "\pi", "3\pi/2", "2\pi"})

FT_X = -6 : 0.0001 : 6;
draw_Y = FT(draw_X);
subplot(2, 1, 2);
plot(FT_X, FT_Y)
title("信号频谱")
xlabel("$\omega$", "Interpreter", "Latex")
ylabel("$F(\mathrm{j}\omega)$", "Interpreter", "Latex")
grid on
% yticks(0 : 1 : 4)
ylim([-1 4])